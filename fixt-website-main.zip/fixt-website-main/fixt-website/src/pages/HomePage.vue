<script setup>
import HomeCarousel from '@/pages/HomeCarousel.vue'
</script>

<template>
  <section class="home-page">
    <h1>Home</h1>
    <p>placeholderrrrr</p>
    <HomeCarousel />
  </section>
</template>
