<script setup>
</script>

<template>
  <section>
    <h1>Contact</h1>
    <p>Placeholder contact page.</p>
    <div class="card">
      <p>Email: placeholder@example.com</p>
      <p>Phone: (000) 000-0000</p>
    </div>
  </section>
</template>
